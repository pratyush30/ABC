package com.testCase;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	public static void main(String args[]) throws Exception
	{		
		String fName= "Pratyush";
		String lName= "Ranjan";
		String currency="Rupee";
		String depositAmt="1000";
		String withdrawAmt="100";		
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver driver= new ChromeDriver();
	
		driver.get("http://www.globalsqa.com/angularjs-protractor-practice-site");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Click to banking
		driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/div/div/div[2]/div[3]/ul/li[2]/a")).click();
		Thread.sleep(900);
		
		//To Add a customer
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/button")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/button[1]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/form/div[1]/input")).sendKeys(fName);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/form/div[2]/input")).sendKeys(lName);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/form/div[3]/input")).sendKeys("560037");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/form/button")).click();
		
		Thread.sleep(500);
		
		Alert alert = driver.switchTo().alert();
		String text = alert.getText();
		System.out.println("Alert Test="+text);
		alert.accept();
			
		driver.switchTo().activeElement();

		//To open An Account
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/button[2]")).click();
		driver.findElement(By.xpath("//*[@id='userSelect']")).sendKeys(fName+" "+lName);
		driver.findElement(By.xpath("//*[@id='currency']")).sendKeys(currency);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/form/button")).click();
		
		Alert alert1 = driver.switchTo().alert();
		String text1 = alert1.getText();
		System.out.println("Alert Test="+text1);
		alert1.accept();

		driver.switchTo().activeElement();


		//Click on Home
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/button[1]")).click();
		
		
		//Go to Customer Section
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[1]/button")).click();
		
		//Select the Customer
		driver.findElement(By.xpath("//*[@id='userSelect']")).sendKeys(fName+" "+lName);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/form/button")).click();
	
		//Click on deposit
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[3]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys(depositAmt);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/form/button")).click();
		
		
		//Verify success message				
		String checkMsg=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/span")).getText();
		if(checkMsg.contains("Deposit Successful"))
			System.out.println("Deposit Successful is displayed");
		else
			System.out.println("Success Message is Not displayed");
	
		Thread.sleep(2000);
	
		//Click on Withdraw
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[3]/button[3]")).click();
		Thread.sleep(900);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys(withdrawAmt);
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/form/button")).click();
		Thread.sleep(2000);
		
		//To Verify message
		String check=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[4]/div/span")).getText();
		if(check.contains("Transaction Successful"))
			System.out.println("Transaction Successful is displayed");
		else
			System.out.println("Transaction Failed");
	
		String accountNum=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/strong[1]")).getText();
		String availableAmt=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[2]/strong[2]")).getText();
		
		System.out.println("Available balence in Account Number "+accountNum +" is "+availableAmt);

		//Click on Logout
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/button[2]")).click();

		Thread.sleep(3000);
		driver.close();		
	}
}
